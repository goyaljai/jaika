import json
import os
import subprocess
import time
import uuid
import shutil
from flask import Flask, render_template, request, jsonify, Response, stream_with_context, send_file

app = Flask(__name__)

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
UPLOAD_DIR = os.path.join(DATA_DIR, "uploads")
# Skills go into ~/.gemini/skills/ so Gemini CLI discovers them natively
SKILLS_DIR = os.path.join(os.path.expanduser("~"), ".gemini", "skills")
SESSIONS_DIR = os.path.join(DATA_DIR, "sessions")
OUTPUTS_DIR = os.path.join(DATA_DIR, "outputs")

for d in [DATA_DIR, UPLOAD_DIR, SKILLS_DIR, SESSIONS_DIR, OUTPUTS_DIR]:
    os.makedirs(d, exist_ok=True)


FALLBACK_MODELS = [
    None,
    "gemini-2.5-pro",
    "gemini-2.5-flash",
    "gemini-2.0-flash",
]

NOISE_FILTERS = [
    "Loaded cached credentials",
    "MCP error",
    "ENOENT",
    "spawn",
    "MCP issues detected",
    "Scheduling MCP context",
    "Executing MCP context",
    "MCP context refresh",
    "GaxiosError",
    "at async",
    "at Gaxios",
    "at OAuth2Client",
    "at CodeAssistServer",
    "at process.",
    "errno:",
    "code: 'ENOENT'",
    "syscall:",
    "spawnargs:",
    "Attempt 1 failed",
    "Attempt 2 failed",
    "Attempt 3 failed",
    "rateLimitExceeded",
    "RESOURCE_EXHAUSTED",
    "MODEL_CAPACITY_EXHAUSTED",
    "at ChildProcess",
    "at onErrorNT",
    "path:",
    "dest:",
    "Failed to save project",
]


def is_noise(line):
    return any(n in line for n in NOISE_FILTERS)


# ── Session helpers ──

def _session_file(session_id):
    return os.path.join(SESSIONS_DIR, f"{session_id}.json")


def _load_session(session_id):
    path = _session_file(session_id)
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)
    return None


def _save_session(session_id, data):
    with open(_session_file(session_id), "w") as f:
        json.dump(data, f)


def _active_session_file():
    return os.path.join(DATA_DIR, "active_session.txt")


def _get_active_session_id():
    path = _active_session_file()
    if os.path.exists(path):
        with open(path, "r") as f:
            sid = f.read().strip()
            if sid and os.path.exists(_session_file(sid)):
                return sid
    # Create default session
    sid = str(uuid.uuid4())[:8]
    _save_session(sid, {"id": sid, "name": "New Chat", "created": time.time(), "messages": []})
    with open(path, "w") as f:
        f.write(sid)
    return sid


def _append_msg(session_id, msg):
    """Append a message to a session."""
    data = _load_session(session_id)
    if data:
        data["messages"].append(msg)
        _save_session(session_id, data)


def _set_active_session(session_id):
    with open(_active_session_file(), "w") as f:
        f.write(session_id)


# ── Routes ──

@app.route("/")
def index():
    return render_template("index.html")


# ── Sessions API ──

@app.route("/api/sessions", methods=["GET"])
def list_sessions():
    sessions = []
    for fname in os.listdir(SESSIONS_DIR):
        if fname.endswith(".json"):
            with open(os.path.join(SESSIONS_DIR, fname)) as f:
                s = json.load(f)
                sessions.append({
                    "id": s["id"],
                    "name": s.get("name", "Untitled"),
                    "created": s.get("created", 0),
                    "message_count": len(s.get("messages", [])),
                })
    sessions.sort(key=lambda x: x["created"], reverse=True)
    active = _get_active_session_id()
    return jsonify({"sessions": sessions, "active": active})


@app.route("/api/sessions", methods=["POST"])
def create_session():
    sid = str(uuid.uuid4())[:8]
    name = request.get_json().get("name", "New Chat") if request.is_json else "New Chat"
    _save_session(sid, {"id": sid, "name": name, "created": time.time(), "messages": []})
    _set_active_session(sid)
    return jsonify({"id": sid, "name": name})


@app.route("/api/sessions/<session_id>", methods=["GET"])
def get_session(session_id):
    data = _load_session(session_id)
    if not data:
        return jsonify({"error": "Not found"}), 404
    _set_active_session(session_id)
    return jsonify(data)


@app.route("/api/sessions/<session_id>", methods=["PUT"])
def update_session(session_id):
    data = _load_session(session_id)
    if not data:
        return jsonify({"error": "Not found"}), 404
    body = request.get_json()
    if "name" in body:
        data["name"] = body["name"]
    _save_session(session_id, data)
    return jsonify({"status": "ok"})


@app.route("/api/sessions/<session_id>", methods=["DELETE"])
def delete_session(session_id):
    # Delete Gemini CLI session if linked
    data = _load_session(session_id)
    if data and data.get("gemini_cli_session"):
        try:
            subprocess.run(
                ["gemini", "--delete-session", data["gemini_cli_session"]],
                capture_output=True, text=True, timeout=10,
                cwd=os.path.expanduser("~"),
            )
        except Exception:
            pass
    path = _session_file(session_id)
    if os.path.exists(path):
        os.remove(path)
    # If we deleted the active session, reset
    if _get_active_session_id() == session_id:
        remaining = [f.replace(".json", "") for f in os.listdir(SESSIONS_DIR) if f.endswith(".json")]
        if remaining:
            _set_active_session(remaining[0])
        else:
            # Create a fresh session
            _get_active_session_id()
    return jsonify({"status": "deleted"})


@app.route("/api/sessions/<session_id>/messages", methods=["POST"])
def append_message(session_id):
    data = _load_session(session_id)
    if not data:
        return jsonify({"error": "Not found"}), 404
    msg = request.get_json()
    data["messages"].append(msg)
    # Auto-name session from first user message
    if data["name"] == "New Chat" and msg.get("role") == "user":
        data["name"] = msg["text"][:40] + ("..." if len(msg["text"]) > 40 else "")
    _save_session(session_id, data)
    return jsonify({"status": "ok"})


@app.route("/api/sessions/<session_id>/messages", methods=["DELETE"])
def clear_messages(session_id):
    data = _load_session(session_id)
    if not data:
        return jsonify({"error": "Not found"}), 404
    data["messages"] = []
    data["name"] = "New Chat"
    _save_session(session_id, data)
    return jsonify({"status": "cleared"})


# ── File upload ──

@app.route("/api/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename"}), 400
    file_id = str(uuid.uuid4())[:8]
    safe_name = f"{file_id}_{f.filename}"
    path = os.path.join(UPLOAD_DIR, safe_name)
    f.save(path)
    return jsonify({"path": path, "name": f.filename})


# ── Skills ──

@app.route("/api/skills", methods=["GET"])
def list_skills():
    skills = []
    if not os.path.exists(SKILLS_DIR):
        os.makedirs(SKILLS_DIR, exist_ok=True)
    for entry in sorted(os.listdir(SKILLS_DIR)):
        skill_dir = os.path.join(SKILLS_DIR, entry)
        skill_file = os.path.join(skill_dir, "SKILL.md")
        if os.path.isdir(skill_dir) and os.path.exists(skill_file):
            skills.append({
                "name": entry,
                "path": skill_file,
            })
    return jsonify(skills)


@app.route("/api/skills/upload", methods=["POST"])
def upload_skill():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    f = request.files["file"]
    if not f.filename or not f.filename.endswith(".md"):
        return jsonify({"error": "Must be a .md file"}), 400
    # Create skill folder named after the file (without .md extension)
    skill_name = f.filename.rsplit(".", 1)[0].replace(" ", "-").lower()
    skill_dir = os.path.join(SKILLS_DIR, skill_name)
    os.makedirs(skill_dir, exist_ok=True)
    path = os.path.join(skill_dir, "SKILL.md")
    f.save(path)
    return jsonify({"path": path, "name": skill_name})


@app.route("/api/skills/<name>", methods=["DELETE"])
def delete_skill(name):
    import shutil
    skill_dir = os.path.join(SKILLS_DIR, name)
    if os.path.isdir(skill_dir):
        shutil.rmtree(skill_dir)
        return jsonify({"status": "deleted"})
    return jsonify({"error": "Not found"}), 404


# ── Gemini prompt ──

import re
import threading


_LATEX_MAP = {
    r'\alpha': 'α', r'\beta': 'β', r'\gamma': 'γ', r'\delta': 'δ',
    r'\epsilon': 'ε', r'\zeta': 'ζ', r'\eta': 'η', r'\theta': 'θ',
    r'\iota': 'ι', r'\kappa': 'κ', r'\lambda': 'λ', r'\mu': 'μ',
    r'\nu': 'ν', r'\xi': 'ξ', r'\pi': 'π', r'\rho': 'ρ',
    r'\sigma': 'σ', r'\tau': 'τ', r'\phi': 'φ', r'\chi': 'χ',
    r'\psi': 'ψ', r'\omega': 'ω',
    r'\Alpha': 'Α', r'\Beta': 'Β', r'\Gamma': 'Γ', r'\Delta': 'Δ',
    r'\Sigma': 'Σ', r'\Pi': 'Π', r'\Omega': 'Ω', r'\Phi': 'Φ',
    r'\Lambda': 'Λ', r'\Theta': 'Θ',
    r'\infty': '∞', r'\pm': '±', r'\times': '×', r'\div': '÷',
    r'\le': '≤', r'\ge': '≥', r'\ne': '≠', r'\approx': '≈',
    r'\in': '∈', r'\notin': '∉', r'\subset': '⊂', r'\supset': '⊃',
    r'\cup': '∪', r'\cap': '∩', r'\emptyset': '∅',
    r'\sum': 'Σ', r'\prod': 'Π', r'\int': '∫',
    r'\partial': '∂', r'\nabla': '∇', r'\forall': '∀', r'\exists': '∃',
    r'\rightarrow': '→', r'\leftarrow': '←', r'\Rightarrow': '⇒',
    r'\sqrt': '√', r'\cdot': '·', r'\ldots': '…', r'\dots': '…',
}

def _latex_to_unicode(text):
    """Convert LaTeX math expressions to readable Unicode."""
    text = text.replace('$', '')
    # Structural LaTeX → readable
    text = re.sub(r'\\frac\{([^}]*)\}\{([^}]*)\}', r'\1/\2', text)
    text = re.sub(r'\\sqrt\{([^}]*)\}', r'sqrt(\1)', text)
    text = re.sub(r'\\binom\{([^}]*)\}\{([^}]*)\}', r'C(\1,\2)', text)
    text = re.sub(r'\\text\{([^}]*)\}', r'\1', text)
    text = re.sub(r'\\mathrm\{([^}]*)\}', r'\1', text)
    text = re.sub(r'\\mathbb\{([^}]*)\}', r'\1', text)
    # Superscript/subscript → caret/underscore notation
    text = re.sub(r'\^\{([^}]*)\}', r'^\1', text)
    text = re.sub(r'_\{([^}]*)\}', r'_\1', text)
    # Replace known LaTeX commands with Unicode (longest first)
    for latex, uni in sorted(_LATEX_MAP.items(), key=lambda x: -len(x[0])):
        text = text.replace(latex, uni)
    # Clean up remaining braces and backslashes
    text = text.replace('{', '').replace('}', '')
    text = re.sub(r'\\[a-zA-Z]+', '', text)
    return text.strip()


def _process_line(text):
    """Process a line: convert inline LaTeX and strip markdown bold/italic."""
    # Convert LaTeX blocks $...$
    text = re.sub(r'\$([^$]+)\$', lambda m: _latex_to_unicode(m.group(1)), text)
    # Strip bold markers
    text = re.sub(r'\*\*(.+?)\*\*', r'\1', text)
    # Strip italic markers
    text = re.sub(r'\*(.+?)\*', r'\1', text)
    return text


def _find_tex_bin():
    """Find TinyTeX or system LaTeX binary path."""
    home = os.path.expanduser("~")
    candidates = [
        os.path.join(home, "Library", "TinyTeX", "bin", "universal-darwin"),
        os.path.join(home, ".TinyTeX", "bin", "x86_64-linux"),
        os.path.join(home, ".TinyTeX", "bin", "aarch64-linux"),
        "/Library/TeX/texbin",
        "/usr/local/texlive/2026/bin/x86_64-linux",
        "/usr/local/texlive/2025/bin/x86_64-linux",
    ]
    for p in candidates:
        if os.path.isdir(p) and os.path.exists(os.path.join(p, "pdflatex")):
            return p
    return None


def _md_to_pdf(md_path, pdf_path):
    """Convert markdown to PDF using pandoc + LaTeX engine."""
    # Build env with TinyTeX on PATH
    env = os.environ.copy()
    tex_bin = _find_tex_bin()
    if tex_bin:
        env["PATH"] = tex_bin + ":" + env.get("PATH", "")

    for engine in ["pdflatex", "xelatex", "lualatex"]:
        try:
            result = subprocess.run(
                ["pandoc", md_path, "-o", pdf_path,
                 f"--pdf-engine={engine}",
                 "-V", "geometry:margin=1in",
                 "-V", "fontsize=11pt"],
                capture_output=True, text=True, timeout=60,
                env=env,
            )
            if result.returncode == 0 and os.path.exists(pdf_path) and os.path.getsize(pdf_path) > 0:
                return
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue

    # If all engines fail, just copy the .md as-is
    shutil.copy2(md_path, pdf_path.replace(".pdf", ".md"))


def _wants_file(prompt_text):
    """Detect if the user is asking Gemini to create/generate a file."""
    p = prompt_text.lower()
    # Action words that imply file creation
    actions = r'\b(create|generate|write|make|build|produce|draft|prepare|compose|save)\b'
    # Object words that imply a file output
    objects = r'\b(file|document|script|pdf|csv|cheatsheet|cheat sheet|spreadsheet|report|template|code|program|page|readme|config|yaml|json|html|markdown)\b'
    return bool(re.search(actions, p) and re.search(objects, p))


@app.route("/api/prompt", methods=["POST"])
def prompt():
    data = request.get_json()
    user_prompt = data.get("prompt", "").strip()
    file_paths = data.get("files", [])
    session_id = data.get("session_id", None)

    # Auto-create session if none provided
    if not session_id:
        session_id = str(uuid.uuid4())[:8]
        _save_session(session_id, {
            "id": session_id,
            "name": user_prompt[:40] + ("..." if len(user_prompt) > 40 else ""),
            "created": time.time(),
            "messages": [],
        })

    if not user_prompt:
        return jsonify({"error": "Empty prompt"}), 400

    is_file_request = _wants_file(user_prompt)

    if is_file_request:
        full_prompt = user_prompt + (
            "\n\nCreate the file and ONLY output the file path."
        )
    else:
        full_prompt = user_prompt

    if file_paths:
        file_section = "\n\nAttached files:\n"
        for fp in file_paths:
            file_section += f"- {fp}\n"
        file_section += "\nPlease read and analyze the above files as part of your response."
        full_prompt += file_section

    home = os.path.expanduser("~")

    # Get Gemini CLI session UUID for conversation memory
    session_data = _load_session(session_id)
    gemini_cli_session = session_data.get("gemini_cli_session") if session_data else None

    def _snapshot_home():
        try:
            return {
                f for f in os.listdir(home)
                if os.path.isfile(os.path.join(home, f))
            }
        except OSError:
            return set()

    def _get_latest_cli_session():
        """Get the UUID of the most recently created Gemini CLI session."""
        try:
            result = subprocess.run(
                ["gemini", "--list-sessions"],
                capture_output=True, text=True, timeout=10, cwd=home,
            )
            # Parse last line: "  39. prompt text (Just now) [uuid]"
            for line in reversed(result.stdout.strip().splitlines()):
                match = re.search(r'\[([a-f0-9-]{36})\]', line)
                if match:
                    return match.group(1)
        except Exception:
            pass
        return None

    for model in FALLBACK_MODELS:
        model_label = model or "default"

        cmd = ["gemini", "--prompt", full_prompt]
        if gemini_cli_session:
            cmd.extend(["--resume", gemini_cli_session])
        if is_file_request:
            cmd.append("--yolo")
        if model:
            cmd.extend(["--model", model])

        before_files = _snapshot_home() if is_file_request else set()

        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            cwd=home,
        )

        stdout_lines = []
        for line in iter(proc.stdout.readline, ""):
            stripped = line.rstrip()
            if is_noise(stripped):
                continue
            if stripped:
                stdout_lines.append(stripped)

        proc.wait()
        stderr = proc.stderr.read()

        capacity_error = (
            "MODEL_CAPACITY_EXHAUSTED" in stderr
            or "RESOURCE_EXHAUSTED" in stderr
            or "rateLimitExceeded" in stderr
            or (proc.returncode != 0 and not stdout_lines)
        )

        if capacity_error and not stdout_lines:
            continue

        # Capture CLI session UUID for memory (only on first call)
        if not gemini_cli_session:
            cli_uuid = _get_latest_cli_session()
            if cli_uuid and session_data:
                session_data["gemini_cli_session"] = cli_uuid
                _save_session(session_id, session_data)
                gemini_cli_session = cli_uuid

        # Build response
        if is_file_request:
            after_files = _snapshot_home()
            new_files = after_files - before_files
            files = []
            for fname in sorted(new_files):
                fpath = os.path.join(home, fname)
                try:
                    out_id = str(uuid.uuid4())[:8]
                    ext = os.path.splitext(fname)[1].lower()

                    # Convert text/markdown files to PDF
                    if ext in ('.md', '.txt', '.csv'):
                        pdf_name_base = os.path.splitext(fname)[0] + ".pdf"
                        out_name = f"{out_id}_{pdf_name_base}"
                        out_path = os.path.join(OUTPUTS_DIR, out_name)
                        _md_to_pdf(fpath, out_path)
                        os.remove(fpath)
                        files.append({"serverName": out_name, "originalName": pdf_name_base})
                    else:
                        out_name = f"{out_id}_{fname}"
                        shutil.move(fpath, os.path.join(OUTPUTS_DIR, out_name))
                        files.append({"serverName": out_name, "originalName": fname})
                except Exception:
                    # Fallback: just move the file as-is
                    try:
                        out_name = f"{out_id}_{fname}"
                        if os.path.exists(fpath):
                            shutil.move(fpath, os.path.join(OUTPUTS_DIR, out_name))
                            files.append({"serverName": out_name, "originalName": fname})
                    except Exception:
                        pass

            if files:
                # Save to session
                _append_msg(session_id, {"role": "user", "text": user_prompt})
                _append_msg(session_id, {"role": "gemini", "text": ", ".join(f["originalName"] for f in files)})
                return jsonify({"type": "files", "files": files, "session_id": session_id})

        # Text response (or file request that didn't create files)
        text = "\n".join(stdout_lines)
        if text:
            _append_msg(session_id, {"role": "user", "text": user_prompt})
            _append_msg(session_id, {"role": "gemini", "text": text})
            return jsonify({"type": "text", "text": text, "session_id": session_id})

    _append_msg(session_id, {"role": "user", "text": user_prompt})
    err_text = "All models are currently at capacity. Please try again in a few minutes."
    _append_msg(session_id, {"role": "gemini", "text": err_text})
    return jsonify({"type": "error", "text": err_text, "session_id": session_id})


@app.route("/api/download/<filename>")
def download_file(filename):
    path = os.path.join(OUTPUTS_DIR, filename)
    if not os.path.exists(path):
        return jsonify({"error": "File not found"}), 404
    # Extract original name (strip uuid prefix)
    original = "_".join(filename.split("_")[1:])
    return send_file(path, as_attachment=True, download_name=original)




def _get_local_ip():
    """Get the machine's LAN/public IP address."""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5244))
    local_ip = _get_local_ip()

    print(f"\n  Local:   http://127.0.0.1:{port}")
    print(f"  Network: http://{local_ip}:{port}\n")

    app.run(host="0.0.0.0", port=port, debug=True)
