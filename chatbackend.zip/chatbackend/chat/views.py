from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from chat.models import Message, Reminder
from chat.serializers import MessageSerializer, ReminderSerializer

class MessageListCreate(generics.ListCreateAPIView):
    queryset = Message.objects.all()
    serializer_class = MessageSerializer
    permission_classes = [IsAuthenticated]

class ReminderListCreate(generics.ListCreateAPIView):
    queryset = Reminder.objects.all()
    serializer_class = ReminderSerializer
    permission_classes = [IsAuthenticated]
